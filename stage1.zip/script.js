'use strict'

let cardsList = document.querySelectorAll('.card');

function flip (event) {
  let targetClass = event.currentTarget.classList;
  if (targetClass.contains('flip')){
    targetClass.remove('flip');
  } else{
    targetClass.add('flip');
  };
};

cardsList.forEach(card => card.addEventListener('click', flip));