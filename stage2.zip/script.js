'use strict'

let cardsList = Array.from(document.querySelectorAll('.card'));

// RANDOM
let randoms = [];
while(randoms.length < 12){
  let num = Math.floor(Math.random() * 12);
  if (randoms.indexOf(num) == -1){
    randoms.push(num);
  }
}

let i = 0;
cardsList.forEach(card => card.setAttribute('style', '--order:' + randoms[i++]));

// OnCLICK
let selectedCounter = 0;

cardsList.forEach(card => card.addEventListener('click', flip));

function flip (event) {
  if (selectedCounter === 2){
    document.querySelectorAll('[data-selected]').forEach(selectedCard => {
      selectedCard.removeAttribute('data-selected');
      if (!selectedCard.classList.contains('match')) selectedCard.classList.remove('flip');
      selectedCard.classList.remove('wrong');
      selectedCounter = 0;
    });
  };

  let target= event.currentTarget;
  if (target.classList.contains('flip')){
    target.classList.remove('flip');
    target.removeAttribute('data-selected');
    selectedCounter--;
  } else{
    target.classList.add('flip');
    target.setAttribute('data-selected', 'true');
    selectedCounter++;
  };

  if(selectedCounter === 2){
    let selectedCards = document.querySelectorAll('[data-selected]');
    if (selectedCards[0].lastElementChild.innerText === selectedCards[1].lastElementChild.innerText){
      selectedCards.forEach(card => {
        card.classList.add('match');
        card.removeEventListener('click', flip);
      });
    } else{
      selectedCards.forEach(card => card.classList.add('wrong'));
    }
  };

};

